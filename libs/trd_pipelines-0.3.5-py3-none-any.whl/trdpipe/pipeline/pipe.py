import abc
from re import S

from pandas.core.frame import DataFrame
from google.cloud import bigquery

from typing import List

from trdpipe.gcpclient.cloudstorage import CSClient
from trdpipe.gcpclient.bigquery import BigQueryLoader
from trdpipe.pipeline.dataloader import DataLoader
from trdpipe.pipeline.transformer import Transformer
from trdpipe.pipeline.parquet import ParquetTransformer
from trdpipe.pipeline.model import Datasets

class GCSPipeline(metaclass=abc.ABCMeta):

    """
    Super class (abstract) to run a pipeline.

    Sub classes must be created and the run function
    must be implemented.
    """

    def __init__(self,bucket:str,
                    bucket_path_s0:str,
                    bucket_path_s1:str,
                    rawFilePatterns:List[str],
                    dataloader:DataLoader,
                    transformer:Transformer):
        """
        constructor

        bucket: GCP Cloud Storage bucket which holds the data
        bucket_path_s0: folder in the bucket which contains 
                        the (raw) data to download and process
        bucket_path_s1: Folder in which the transformed data 
                        is gonna be written in parquet format. 
                        The load to bigquery also makes use of this folder.
        rawFilePatterns: list of unix based file matching pattern to filter from the s0_folder
        dataloader: class which inherits from DataLoader and loads the data for the pipe
        transformer: class which inherits from Transformer and transforms the data pipeline specifically
        """
        self.bucket = bucket
        self.bucket_path_s0 = bucket_path_s0
        self.bucket_path_s1 = bucket_path_s1
        self.rawFilePatterns = rawFilePatterns
        self.dataloader = dataloader
        self.transformer = transformer

    @classmethod
    def __subclasshook__(cls, subclass):
        return (hasattr(subclass, 'run') and 
                callable(subclass.run))
    
    @abc.abstractmethod
    def run(self):
        raise NotImplementedError

    def _loadAndTransformData(self) -> Datasets:
        """
        Loads the given data from GSC into several
        pandas dataframes and transforms them.

        The loading and the transforming make use
        of project specific subclasses.

        return: datasets instance with the transformed data
        """
        # download files from the given bucket
        filenames = self.__downloadFromGCS()

        #load the files into pandas dataframes within a datasets class
        datasets = self.__loadData2Datasets(filenames)

        #transform the dataframes, 
        # for example make type conversions, 
        # clean the data, create feature, merge them etc.
        datasets = self.__transformFeatures(datasets)

        return datasets

    def __downloadFromGCS(self):
        """
        Downloads the necessary files to local from Cloud Storage.

        return: list of filenames that were downloaded (full path)
        """
        l = []
        for pat in self.rawFilePatterns:
            cs_cl = CSClient(bucket=self.bucket)
            fls = cs_cl.download(path=self.bucket_path_s0, fileFilter=pat)
            if fls is not None:
                l.extend(fls)
        return l

    def __loadData2Datasets(self, filenames:List[str]) -> Datasets:
        """
        Loads the downloaded files into pandas dataframes and
        adds them to a Datasets instance.

        The is pipeline specific and uses the given DataLoader instance
        which is basically an interface with the main function load2Datasets.
        This function has to be implemented for every specific pipeline.

        return: instance of Datasets
        """
        return self.dataloader.load2Datasets(filenames)

    def __transformFeatures(self, datasets: Datasets) -> Datasets:
        """
        Transforms data of a given Datasets instance.

        The is pipeline specific and uses the given Transformer instance
        which is basically an interface with the main function transform.
        This function has to be implemented for every specific pipeline.

        return: instance of Datasets
        """
        return self.transformer.transform(datasets)


class GCS2BigQueryPipe(GCSPipeline):

    """
    A pipeline to load data from GCS, 
    transform it and stores it to Bigquery.
    """

    def __init__(self, 
                    bucket:str,
                    bucket_path_s0:str,
                    bucket_path_s1:str,
                    rawFilePatterns:List[str],
                    gcp_project:str,
                    bq_dataset:str,
                    bq_table:str,
                    bq_write_disposition:str,
                    dataloader:DataLoader,
                    transformer:Transformer):
                    
        """
        constructor

        gcp_project: id of the GCP project which contains the BQ dataset
        bq_dataset: name of the bq dataset which will contain the table
        bq_table: table_id of the table in bq to create or to load the data to
        bq_write_disposition: write disposition of the request, e.g. WRITE_TRUNCATE
            details: https://googleapis.dev/python/bigquery/latest/generated/google.cloud.bigquery.job.WriteDisposition.html
        """

        super().__init__(bucket=bucket, 
                         bucket_path_s0=bucket_path_s0,
                         bucket_path_s1=bucket_path_s1,
                         rawFilePatterns=rawFilePatterns,
                         dataloader=dataloader,
                         transformer=transformer)

        self.gcp_project = gcp_project
        self.bq_dataset = bq_dataset
        self.bq_table = bq_table
        self.bq_write_disposition = bq_write_disposition

    def run(self):
        """
        Function that runs the complete pipeline
        """

        #load and transform the data from GCS
        datasets = self._loadAndTransformData()

        #in the current version it is only
        #possible to output one final dataframe
        #and save it to a big query table
        if datasets.getNumberOfDataframes() > 1:
            raise ValueError("""only one output dataframe 
                                is supported by GCS2Bigquery""")
        df = datasets.getByIndex(0)

        #save the transformed dataframe to a parquet file
        parquetFile = self.__transform2Parquet(df)

        #upload the parquet file to a GCP bucket
        parquetBlob = self.__upload2GCS(parquetFile)

        #load the parquet file to a BigQuery table
        self.__load2BigQuery(blobname=parquetBlob)

    def __transform2Parquet(self, df:DataFrame) -> str:
        """
        Transforms the finished dataframe to parquet
        and saves it as a parquet file.

        df: finished pandas dataframe

        return: fully qualified path to the locally saved file
        """
        return ParquetTransformer().transform2Parquet(df)

    def __upload2GCS(self, localFile:str):
        """
        Uploads the created parquet file to the given GCP Bucket,
        using the specified S1-path.

        localFile: fully qualified path to the local parquet file

        return: name of the uploaded blob
        """
        cs_cl = CSClient(bucket=self.bucket)
        return cs_cl.upload(srcPath=localFile, targetFolder=self.bucket_path_s1)

    def __load2BigQuery(self, blobname):
        """
        Loads the uploaded parquet file to BigQuery.

        blobname: name of the uploaded blob
        """
        bql = BigQueryLoader(project=self.gcp_project, dataset=self.bq_dataset)
        bql.loadFromUri(table_id=self.bq_table, 
                        uri=f"gs://{self.bucket}/{blobname}",
                        source_format=bigquery.SourceFormat.PARQUET,
                        write_disposition=self.bq_write_disposition)

class GCS2GCSPipe(GCSPipeline):

    """
    A pipeline to load data from GCS, 
    transform it and stores it back to GCS.
    """

    def __init__(self, 
                    bucket:str,
                    bucket_path_s0:str,
                    bucket_path_s1:str,
                    rawFilePatterns:List[str],
                    s1_file_type:str,
                    s1_file_sep:str,
                    dataloader:DataLoader,
                    transformer:Transformer,
                    tmpPath="/tmp"):     
        """
        constructor

        s1_file_type:   format in which the transformed 
                        files should be saved (csv/xlsx)
        s1_file_sep:    separator of the transformed files 
                        (only applies if file_type = 'csv')
        tmpPath:        local path where files should be stored
                        before the will be uploaded to GCS
        """
        super().__init__(bucket=bucket, 
                         bucket_path_s0=bucket_path_s0,
                         bucket_path_s1=bucket_path_s1,
                         rawFilePatterns=rawFilePatterns,
                         dataloader=dataloader,
                         transformer=transformer)

        if s1_file_type not in ['csv','xlsx']:
            raise ValueError(f"file type {s1_file_type} is not supported")
        self.s1_file_type = s1_file_type
        
        self.s1_file_sep = s1_file_sep
        
        self.tmpPath = tmpPath

    def run(self):
        """
        Function that runs the complete pipeline.

        Loads, transforms the data and uploads it
        to GCS.
        """
        #load and transform the data from GCS
        datasets = self._loadAndTransformData()

        self.__uploadDatasets2GCS(datasets=datasets)

    def __uploadDatasets2GCS(self, datasets:Datasets):
        """
        TODO: move to super class
        TODO: return object names on GCS for further processing
        Uploads the data to GCS.

        datasets: instance of Datasets
        """
        #init client
        cs_cl = CSClient(bucket=self.bucket)
        #iterate over each dataset
        for id, df in datasets.getData().items():
            #save pandas dataframe to a file
            lclFile = self.__saveDataFrame(id=id, df=df)
            #upload the local file to GCS
            cs_cl.upload(srcPath=lclFile, targetFolder=self.bucket_path_s1)   

    def __saveDataFrame(self, id:str, df:DataFrame):
        """
        Saves a pandas dataframe to a local file.

        id: id of the dataset
        df: pandas dataframe

        return: filename of the stored file
        """
        #creates filename (combination of id and file_type)
        filename = f"{self.tmpPath}/{id}.{self.s1_file_type}"
        #store to csv
        if self.s1_file_type == 'csv':
            df.to_csv(filename, sep=self.s1_file_sep, index=False)
        #store to excel
        elif self.s1_file_type == 'xlsx':
            df.to_excel(filename, index=False)
        else:
            raise ValueError(f"file type {self.s1_file_type} is not supported")

        return filename