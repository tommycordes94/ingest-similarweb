import abc
from trdpipe.pipeline.model import Datasets

class Transformer(metaclass=abc.ABCMeta):

    """
    Base class for data transforms which is basically an
    interface.

    Main function that needs to be implemented: transform
    """

    @classmethod
    def __subclasshook__(cls, subclass):
        return (hasattr(subclass, 'transform') and 
                callable(subclass.transform))
    
    @abc.abstractmethod
    def transform(self, datasets:Datasets) -> Datasets:
        """
        Function that takes a datasets instance, performs
        some transforms and returns a datasets instance.
        """
        raise NotImplementedError