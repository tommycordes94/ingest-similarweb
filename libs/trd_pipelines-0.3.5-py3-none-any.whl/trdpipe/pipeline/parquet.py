import pyarrow as pa
import pyarrow.parquet as pq
import secrets

class ParquetTransformer():

    def __init__(self, targetPath="/tmp/"):
        self.targetPath = targetPath

    def transform2Parquet(self, df, filename=None):
        if filename is None:
            filename = f"{secrets.token_urlsafe(16)}.parquet"
        table = pa.Table.from_pandas(df, preserve_index=False)
        fn_fullspec = f"{self.targetPath}{filename}"
        pq.write_table(table,f"{self.targetPath}{filename}")
        return fn_fullspec