from pandas import DataFrame

class Datasets():

    """
    Class to hold and transfer identifiable
    dataframes.
    """

    def __init__(self) -> None:
        self.data = {}

    def addData(self, id:str, df:DataFrame):
        """add a dataframe to the set"""
        self.data[id] = df

    def get(self, id):
        """gets a dataframe by id"""
        return self.data.get(id)

    def getByIndex(self, idx:int):
        """gets a dataframe by index"""
        return list(self.data.values())[idx]

    def getData(self):
        """gets all dataframes"""
        return self.data

    def getNumberOfDataframes(self):
        """gets number of dfs"""
        return len(self.data)
