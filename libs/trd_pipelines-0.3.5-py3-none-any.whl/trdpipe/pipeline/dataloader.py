import abc
from typing import List

from trdpipe.pipeline.model import Datasets

class DataLoader(metaclass=abc.ABCMeta):

    """
    Base class for data loaders which is basically an
    interface.

    Main function that needs to be implemented: load2DataFrame
    """

    @classmethod
    def __subclasshook__(cls, subclass):
        return (hasattr(subclass, 'load2DataFrame') and 
                callable(subclass.load2DataFrame))
    
    @abc.abstractmethod
    def load2Datasets(self, filenames:List[str]) -> Datasets:
        """
        Function that takes a list of file names, loads
        the files and adds them to a Datasets instance.
        """
        raise NotImplementedError