from distutils.command.config import config
import pytest
import pathlib

from trdpipe.structify_publish.helper import (
    DATA_DOMAIN,
    DATA_SOURCE,
    DATA_SUBSOURCE,
    get_datasource_level,
    getSubclass, 
    loadConfig, 
    getModuleName, 
    getSubSource,
    list_modules)
from trdpipe.structify_publish.structify import BaseStructifier

basepath = str(pathlib.Path(__file__).parent)

class Wrangler(BaseStructifier):
    """
    Test wrangler with NO implementation of the needed methods
    """
    pass

def test_getModuleName():
    assert getModuleName("pippi.lang") == "pippi.lang"
    assert getModuleName("pippi.lang.strumpf") == "pippi.lang"

def test_getSubSource():
    assert getSubSource("pippi.lang") is None
    assert getSubSource("pippi.lang.strumpf") == "strumpf"

def test_getSubClass_ok():
    # known data source -> should return a class instance
    i = getSubclass("hollywood.actors", package="trdpipe.structify_publish.test")
    assert i is not None
    assert issubclass(i, BaseStructifier)

def test_getSubClass_with_dataset():
    # known data source -> should return a class instance
    i = getSubclass("hollywood.actors.subset_1", package="trdpipe.structify_publish.test")

def test_getSubClass_src_unknown():
    # data source unknown
    with pytest.raises(ValueError):
        i = getSubclass("universities.somesource")

def test_getSubClass_class_invalid():
    # wrangler which is not implemented correctly
    with pytest.raises(ValueError):
        i = getSubclass(datasrc="test_subclass", package="test")

def test_loadConfig():
    conf = loadConfig('local',basepath)
    assert conf is not None

def test_loadConfig_notexists():
    with pytest.raises(ValueError):
        loadConfig(
            'locally_teddybear',
            str(pathlib.Path(basepath).joinpath('config')))

def test_listmodules():
    modules = list_modules('src/trdpipe/structify_publish/test/hollywood')
    assert modules is not None
    assert len(modules) == 1
    assert 'actors' in modules

def test_getdatasourcelvl():
    assert get_datasource_level("hollywood") == DATA_DOMAIN
    assert get_datasource_level("hollywood.actors") == DATA_SOURCE
    assert get_datasource_level("hollywood.actors.americans") == DATA_SUBSOURCE
    assert get_datasource_level("hollywood.actors.americans.californian") == DATA_SUBSOURCE