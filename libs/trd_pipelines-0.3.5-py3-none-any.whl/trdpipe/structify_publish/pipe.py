import pathlib
import glob
import os
import pathlib
import glob
import os
from datetime import datetime
import shutil
from pandas import DataFrame
import json
import sys
import logging

from trdpipe.gcpclient.cloudstorage import CSClient

from .validator import Validator

from trdpipe.structify_publish.const import (
    STORAGE_GCP, STORAGE_LOCAL, STAGE_RAW, 
    STAGE_PUBL, STAGE_CALC, 
    FORMAT_CSV, FORMAT_PARQUET, FORMAT_JSON, FORMAT_XLSX)


class BasePipe():

    def __init__(
            self,
            config: dict,
            params: dict = None,
            subsrc: str = None):
        self.config = config
        self.params = params
        self.subsrc = subsrc
        self.workdir = config.get(
            'workdir', '/tmp') if config is not None else None

    def _findLatestDate(self, dataset: str, f_ext: str, stage: str) -> str:
        fls = self._collectFiles(
            dataset=dataset,
            f_ext=f_ext,
            stage=stage)

        return self._findFilesMaxDate(fls)

    def _findLatest(self, dataset: str, f_ext: str, stage: str) -> str:
        fls = self._collectFiles(
            dataset=dataset,
            f_ext=f_ext,
            stage=stage)

        latestF = self._findFileWithMaxDate(fls)
        if latestF is None:
            logging.warning(f"could not find file with max date for {dataset} on stage {stage}")
            return None

        return self._getFile(filePath=latestF, stage=stage)

    def _getFile(
        self, 
        filePath, 
        stage, 
        as_stream=False):
        """
        Either returns a file if stored locally OR
        downloads the given file from GCP and 
        returns a local path to it.
        """
        if self._getStorage() == STORAGE_GCP:
            gsPath = self._getPath(stage=stage)
            csClient = CSClient(bucket=self._extractBucket(gsPath))
            return csClient.downloadBlob(
                path=filePath, 
                targetPath=f"{self.workdir}/",
                as_stream=as_stream)
        else:
            return filePath

    def _collectFiles(self, dataset: str, f_ext: str, stage: str):
        if self._getStorage() == STORAGE_GCP:
            fls = self._collectGCPFiles(path=self._getPath(
                stage=stage), dataset=dataset, f_ext=f_ext)
        else:
            path = pathlib.Path(self._getPath(stage=stage))
            if path.exists() == False:
                raise ValueError(f"path {path} doesn't exist")
            glxpr = f"{path.resolve()}/{dataset}*.{f_ext}"
            fls = glob.glob(glxpr)

        if len(fls) == 0:
            return None

        return fls

    def _findFilesMaxDate(self, files: list) -> str:
        if files is None:
            return None
        dates = [self._extractDateFromFilename(f)
                 for f in files if self._extractDateFromFilename(f) is not None]
        if len(dates) == 0:
            raise ValueError(
                f"no files found matching the format '<filename>_%Y%m%d.<extension>")
        return datetime.strftime(max(dates), "%Y%m%d")

    def _findFileWithMaxDate(self, files: list):
        maxDateStr = self._findFilesMaxDate(files)
        if maxDateStr is None:
            return None
        return [f for f in files if maxDateStr in f][0]

    def _extractDateFromFilename(self, f):
        try:
            fileRoot = os.path.split(f)[1].split('.')[0]
            return datetime.strptime(fileRoot[-8:], '%Y%m%d')
        except ValueError:
            return None

    def _getPath(self, stage: str) -> str:
        if 'base_path' not in self.config:
            raise ValueError("no base_path provided in config")
        subPath = self.datasource.replace(".", "/")
        fullPath = f"{self.config['base_path']}/{stage}/{subPath}"
        if self.subsrc is None:
            return fullPath
        else:
            return f"{fullPath}/{self.subsrc.replace('.', '/')}"

    def _getStorage(self):
        if 'base_path' not in self.config:
            raise ValueError("no base_path provided in config")
        if self.config['base_path'].startswith("gs://"):
            return STORAGE_GCP
        else:
            return STORAGE_LOCAL

    def _collectGCPFiles(self, path: str, dataset: str, f_ext: str):
        print("path:", path)
        csClient = CSClient(bucket=self._extractBucket(path))
        p = self._extractBucketPath(path)
        glxpr = f"{p}/{dataset}*.{f_ext}"
        return csClient.listBlobs(path=p, fileFilter=glxpr)

    def _extractBucket(self, path: str):
        return path.replace("gs://", "").split("/")[0]

    def _extractBucketPath(self, path: str):
        p = path.replace("gs://", "")
        folders = [p1 for p1 in p.split("/")]
        return "/".join([p for p in folders[1:]])

    def _collectSubSources(self, stage):
        srcs = None
        if self._getStorage() == STORAGE_GCP:
            path = self._getPath(
                stage=stage)
            srcs = self._collectGCPSubSources(path=path)
            srcs = [s.replace(
                self._extractBucketPath(path)+"/", '').split(
                    '/')[0] for s in srcs]
        else:
            path = pathlib.Path(self._getPath(stage=stage))
            if path.exists() == False:
                raise ValueError(f"path {path} doesn't exist")
            srcs = glob.glob(f"{path}/*/", recursive=False)
            srcs = [os.path.split(s[:-1])[1] for s in srcs]

        if len(srcs) == 0:
            return None

        # make it unique
        return set(srcs)

    def _collectGCPSubSources(self, path: str):
        print(self._extractBucket(path))
        csClient = CSClient(bucket=self._extractBucket(path))
        p = self._extractBucketPath(path)
        glxpr = f"{p}/*"
        print(glxpr)
        return csClient.listBlobs(path=p, fileFilter=glxpr)

    def _push(
            self,
            dataset: str,
            data: DataFrame,
            timestamp: str,
            formats: str,
            create_latest: bool = True,
            create_timebased: bool = True,
            add_timestamp2data: bool = True,
            validate: bool = True,
            schema_name: str = None,
            stage: str = STAGE_PUBL,
            push_schema_by_name_only = False):

        if dataset is None or len(dataset) == 0:
            raise ValueError("data cannot be pushed - no dataset provided")
        if '.' in dataset:
            raise ValueError(
                "data cannot be pushed - dataset invalid (please do not use periods -> (.))")
        if data is None:
            raise ValueError("data cannot be pushed - no data provided")
        try:
            ts = datetime.strptime(timestamp, "%Y%m%d")
        except ValueError:
            raise ValueError(
                "data cannot be pushed - timestamp invalid, provide it in the format '%Y%m%d'")
        if add_timestamp2data:
            if 'timestamp' not in data.columns:
                data["timestamp"] = ts
            else:
                msg = "data cannot be pushed - already contains a timestamp."
                msg = msg + " consider setting 'add_timestamp2data' to false"
                raise ValueError(msg)

        schema = None
        v = Validator()
        if schema_name is not None:
            schema = v.getJsonSchema(
                root=sys.modules[self.__class__.__module__].__file__,
                dataset=schema_name if schema_name is not None else dataset)

        if validate:
            v.validate(data, schema)

        for f in formats.split(","):
            self.__pushFormat(
                dataset=dataset,
                data=data,
                timestamp=timestamp,
                format=f.strip(),
                create_latest=create_latest,
                create_timebased=create_timebased,
                stage=stage)

        if schema is not None:
            self.__pushSchema(
                dataset=dataset,
                timestamp=timestamp,
                schema=schema,
                schema_name=schema_name,
                create_latest=create_latest,
                create_timebased=create_timebased,
                stage=stage,
                push_schema_by_name_only=push_schema_by_name_only)

    def __pushSchema(
            self,
            dataset,
            timestamp,
            schema,
            schema_name,
            create_latest,
            create_timebased,
            stage=STAGE_PUBL,
            push_schema_by_name_only=False):

        if push_schema_by_name_only:
            filename = f"{self.workdir}/meta_{schema_name}.json"
        else:
            filename = f"{self.workdir}/meta_{dataset}.json"
        
        with open(filename, 'w') as f:
            json.dump(schema, f)

        self._pushFile(
            filename,
            timestamp,
            create_latest,
            create_timebased,
            stage)

    def _pushFile(
            self,
            filename,
            timestamp,
            create_latest,
            create_timebased,
            stage=STAGE_PUBL):

        target_file_names = self.__create_target_file_names(
            filename=filename, 
            timestamp=timestamp, 
            create_latest=create_latest, 
            create_timebased=create_timebased,
            stage=stage)

        for tf in target_file_names:
            if self._getStorage() == STORAGE_GCP:
                # upload to gcp
                gsPath = self._getPath(stage=stage)
                csClient = CSClient(bucket=self._extractBucket(gsPath))
                csClient.upload(tf[1], self._extractBucketPath(gsPath))
            else:
                # local copy to target folder
                path = pathlib.Path(self._getPath(stage=stage))
                if path.exists() == False:
                    os.makedirs(path)
                shutil.copyfile(tf[0], tf[1])

    def __pushFormat(
            self,
            dataset: str,
            data: DataFrame,
            timestamp: str,
            format: str,
            create_latest: bool,
            create_timebased: bool,
            stage=STAGE_PUBL):

        #create tmp local file
        filename = f"{self.workdir}/{dataset}.{format}"

        if format == FORMAT_CSV:
            data.to_csv(filename, index=False)
        elif format == FORMAT_PARQUET:
            data.to_parquet(filename, index=False)
        elif format == FORMAT_JSON:
            data.to_json(filename, orient="index")
        elif format == FORMAT_XLSX:
            data.to_excel(filename, index=False)
        else:
            raise ValueError(
                f"data cannot be pushed - unknown data format {format}")

        self._pushFile(
            filename,
            timestamp,
            create_latest,
            create_timebased,
            stage)

    def __create_target_file_names(
        self, 
        filename, 
        timestamp, 
        create_latest, 
        create_timebased,
        stage):

        target_filenames = []
        f_ext = filename.split('.')[-1]
        f_root = os.path.split(filename.replace(f".{f_ext}", ''))[1]
        if self._getStorage() == STORAGE_GCP:
            path = os.path.split(filename)[0]
        else:
            path = pathlib.Path(self._getPath(stage=stage))

        if create_latest == False and create_timebased == False:
            target_filenames.append((filename,f"{path}/{f_root}.{f_ext}"))
        if create_latest:
            target_filename = f"{path}/{f_root}_latest.{f_ext}"
            if self._getStorage() == STORAGE_GCP: # if gcp make a local copy in tmp folder
                shutil.copyfile(filename, target_filename)
            target_filenames.append((filename,target_filename))
        if create_timebased:
            target_filename = f"{path}/{f_root}_{timestamp}.{f_ext}"
            if self._getStorage() == STORAGE_GCP: # if gcp make a local copy in tmp folder
                shutil.copyfile(filename, target_filename)
            target_filenames.append((filename,target_filename))

        return target_filenames