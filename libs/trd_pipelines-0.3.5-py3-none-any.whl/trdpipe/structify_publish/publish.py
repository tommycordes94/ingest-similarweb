import os
import json
import logging

from trdpipe.gcpclient.cloudstorage import CSClient
from trdpipe.structify_publish.pipe import BasePipe
from trdpipe.structify_publish.const import (
    STAGE_PUBL, DATA_SOURCE, DATA_SUBSOURCE)

from trdpipe.structify_publish.helper import (
    get_datasource_level)

class PublisherMeta(type):

    def __instancecheck__(cls, instance):
        return cls.__subclasscheck__(type(instance))

    def __subclasscheck__(cls, subclass):
        return (hasattr(subclass, 'publish') and
                callable(subclass.publish))

class BasePublisher(BasePipe, metaclass=PublisherMeta):

    def __init__(
            self,
            config,
            datasource,
            stage=STAGE_PUBL, 
            latest_only=False):
        super().__init__(config=config)
        self.datasource = datasource
        self.stage = stage
        self.latest_only = latest_only
        self.datadomain = datasource.split('.')[0]

    def _collect_gcp_files(self, dataset=None):
        path = self._get_path()
        csClient = CSClient(bucket=self._extractBucket(path))
        p = self._extractBucketPath(path)
        f = None
        if dataset is not None:
            p = f"{p}/"
            f = f"*{dataset}*"
        elif get_datasource_level(self.datasource) == DATA_SUBSOURCE:
            p = os.path.split(p)[0]
            f = f"*{os.path.split(self._extractBucketPath(path))[1]}"
            f = f"{f}_latest" if self.latest_only else f"{f}*"
        elif get_datasource_level(self.datasource) == DATA_SOURCE:
            p = f"{p}/"
            f = "*latest*" if self.latest_only else "*"
        files = csClient.listBlobs(
            path=p,
            fileFilter=f)
        files = list(map(lambda x: self.__get_gs_uri(x), files))
        logging.info(f"found the following files: {files}")
        return self.__get_data_meta_pairs(files, dataset=dataset)

    def __get_data_meta_pairs(self, files, dataset=None):
        fd = {}
        for f in files:
            if f.endswith("/"):
                continue
            if self.__is_metafile(f) == False:
                fd[f] = self.__find_meta_file(f, files, dataset=dataset)

        return fd

    def __find_meta_file(self, f, files, dataset=None):
        if dataset is None:
            f_ext = f.split('.')[1]
            f_meta = os.path.split(f)[1].replace(f'.{f_ext}', '.json')
            f_meta = f"{os.path.split(f)[0]}/meta_{f_meta}"
        else:
            f_meta = f"{os.path.split(f)[0]}/meta_{dataset}.json"

        for x in files:
            if x == f_meta:
                return x

        raise ValueError(f"no meta file found for {f}")

    def __get_gs_uri(self, f):
        bucket = self.config['base_path'].replace("gs://", "").split("/")[0]
        return f"gs://{bucket}/{f}"

    def _get_path(self) -> str:
        if 'base_path' not in self.config:
            raise ValueError("no base_path provided in config")
        subPath = self.datasource.replace(".", "/")
        return f"{self.config['base_path']}/{self.stage}/{subPath}"

    def __is_metafile(self, file: str) -> bool:
        return os.path.split(file)[1].startswith('meta_')

    def _load_metafile(self, uri: str) -> dict:
        csClient = CSClient(bucket=self._extractBucket(uri))
        l_file = csClient.downloadBlob(
            path=self._extractBucketPath(uri), targetPath=f"{self.workdir}/")
        with open(l_file, 'r') as f:
            return json.load(f)