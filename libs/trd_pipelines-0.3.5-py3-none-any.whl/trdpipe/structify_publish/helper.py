import pathlib
import importlib
import yaml
import sys
import inspect
from .structify import BaseStructifier

from trdpipe.structify_publish.const import (
    DATA_DOMAIN, DATA_SOURCE, DATA_SUBSOURCE)

def getModuleName(datasrc):
    ps = datasrc.split('.')
    if len(ps) == 2:
        return datasrc
    elif len(ps) >= 3:
        return ".".join(ps[:2])
    else:
        raise ValueError("datasrc seems to be invalid")

def getSubSource(datasrc):
    ps = datasrc.split('.')
    if len(ps) >= 3:
        return ".".join(ps[2:])
    else:
        return None

def getSubclass(datasrc, package="service", **kwargs):
    """
    Imports a module depending on the data source and
    creates an instance of type BaseWrangler. Also
    checks the correct implementation of the structifier.
    """
    try:
        mod_name = getModuleName(datasrc)
        print(f"import {mod_name}")
        mod = importlib.import_module(name=f".{mod_name}", package=package)
        class_ = getattr(mod, "Structifier")
        instance = class_(config=kwargs.get('config', None),
                          params=kwargs.get('params', None),
                          subsrc=getSubSource(datasrc))
        if issubclass(class_, BaseStructifier) == False:
            raise ValueError(
                f"structifier for data source '{datasrc}' is not implemented correctly - not a subclass")
        return instance
    except ModuleNotFoundError:
        raise ValueError(f"data source '{datasrc}' is unknown or invalid")
    except AttributeError:
        raise ValueError(
            f"structifier for data source '{datasrc}' is not implemented correctly - no class 'Structifier'")


def loadConfig(env, path:str):
    conf = pathlib.Path(path).joinpath(
        "config").joinpath(f"{env}.yaml")
    try:
        with open(conf, "r") as stream:
            try:
                return yaml.safe_load(stream)
            except yaml.YAMLError as exc:
                print(exc)
    except FileNotFoundError:
        raise ValueError(f"no config found for env '{env}' - it needs to be declared in the conf folder of this service")


def list_modules(package_path:str):
    import pkgutil
    results = []
    mods = [name for _, name, _ in pkgutil.iter_modules([package_path])]
    for m in mods:
        m_name = f"{package_path}.{m}".replace("/",".")
        importlib.import_module(name=m_name)
        for name, obj in inspect.getmembers(sys.modules[m_name]):
            if inspect.isclass(obj) and issubclass(obj, BaseStructifier):
                results.append(m)

    return results
            
def get_datasource_level(datasource:str) -> str:
    if datasource is None:
        raise ValueError("no datasource provided")

    spl = datasource.split('.')
    if len(spl) == 1:
        return DATA_DOMAIN
    elif len(spl) == 2:
        return DATA_SOURCE
    elif len(spl) >= 3:
        return DATA_SUBSOURCE
    else:
        raise ValueError(f"datasource {datasource} is invalid")