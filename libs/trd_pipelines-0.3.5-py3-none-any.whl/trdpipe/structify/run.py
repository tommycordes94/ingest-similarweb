import logging

from trdpipe.structify_publish.helper import (
    getSubclass,
    loadConfig,
    list_modules,
    get_datasource_level,
    DATA_DOMAIN)

def run_datasrc(ds, env, formats):
    logging.info(f"start wrangling '{ds}' at stage '{env}'")
    getSubclass(
        ds,
        config=loadConfig(env, path=''),
        params={'formats': formats}).wrangle()
    success = f"data source '{ds}' successfully wrangled at stage '{env}'"
    logging.info(success)


def run(datasrc, env, formats, module_root="service"):
    if get_datasource_level(datasrc) == DATA_DOMAIN:
        modules = list_modules(f"{module_root}/{datasrc}")
        for m in modules:
            run_datasrc(f"{datasrc}.{m}", env, formats)
    else:
        run_datasrc(datasrc, env, formats)