from trdpipe.structify.base import BaseWrangler

class Wrangler(BaseWrangler):

    datasource = "hollywood.actors"

    def wrangle(self):
        pass