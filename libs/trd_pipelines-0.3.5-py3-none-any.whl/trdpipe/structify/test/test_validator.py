import pytest
import pandas as pd
import numpy as np
import jsonschema

from trdpipe.structify_publish.validator import Validator
from trdpipe.structify_publish.test.hollywood import actors


def test_loadJsonSchema():
    v = Validator()
    v.getJsonSchema(actors.__file__, "houses")


def test_loadJsonSchema_notexist():
    with pytest.raises(ValueError):
        v = Validator()
        v.getJsonSchema(actors.__file__, "yachts")


def test_loadJsonSchema_invalid():
    with pytest.raises(ValueError):
        v = Validator()
        v.getJsonSchema(actors.__file__, "cars")


def test_validate():
    data = pd.DataFrame(data={
        'actor_id': [1, 2],
        'name': ['bruce', 'arnold'],
        'house_size': [100, 200]})
    v = Validator()
    v.validate(data, schema=v.getJsonSchema(
        actors.__file__,
        "houses"))


def test_validate_fail1():
    # value for house size greater than 1000
    with pytest.raises(jsonschema.ValidationError):
        data = pd.DataFrame(data={
            'actor_id': [1, 2],
            'name': ['bruce', 'arnold'],
            'house_size': [100, 2000]})
        v = Validator()
        v.validate(data, schema=v.getJsonSchema(
            actors.__file__,
            "houses"))


def test_validate_fail2():
    # no column 'house_size'
    with pytest.raises(jsonschema.ValidationError):
        data = pd.DataFrame(data={
            'actor_id': [1, 2],
            'name': ['bruce', 'arnold']})
        v = Validator()
        v.validate(data, schema=v.getJsonSchema(
            actors.__file__,
            "houses"))


def test_validate_fail3():
    # null value in house size
    with pytest.raises(jsonschema.ValidationError):
        data = pd.DataFrame(data={
            'actor_id': [1, 2],
            'name': ['bruce', 'arnold'],
            'house_size': [100, np.nan]})
        v = Validator()
        v.validate(data, schema=v.getJsonSchema(
            actors.__file__,
            "houses"))


def test_validate_fail4():
    # additional column
    with pytest.raises(jsonschema.ValidationError):
        data = pd.DataFrame(data={
            'actor_id': [1, 2],
            'name': ['bruce', 'arnold'],
            'house_size': [100, 200],
            'shoe_size': [8.5, 11]})
        v = Validator()
        v.validate(data, schema=v.getJsonSchema(
            actors.__file__,
            "houses"))
