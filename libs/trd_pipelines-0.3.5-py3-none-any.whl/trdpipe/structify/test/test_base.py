import pytest
from trdpipe.structify.base import BaseWrangler
import os
import pandas as pd

from trdpipe.structify_publish.test.hollywood import actors


class TestWrangler(BaseWrangler):
    datasource = "hollywood.actors"

    def wrangle(self):
        pass

class TestWranglerStudies(BaseWrangler):
    datasource = "studies.internal"

    def wrangle(self):
        pass

TestWrangler.__test__ = False
TestWranglerStudies.__test__ = False


def test_getPath():
    tw = TestWrangler(config={'base_path': 'trdpipe/structify/test/data'}, params={})
    assert issubclass(tw, BaseWrangler)
    p = tw._BaseWrangler__getPath(stage="raw")
    assert p is not None
    assert p == 'trdpipe/structify/test/data/raw/hollywood/actors'


def test_getPath_subsrc():
    tw = TestWrangler(config={'base_path': 'trdpipe/structify/test/data'},
                      params={}, subsrc="houses")
    assert issubclass(tw, BaseWrangler)
    p = tw._BaseWrangler__getPath(stage="raw")
    assert p is not None
    assert p == 'trdpipe/structify/test/data/raw/hollywood/actors/houses'


def test_getPath_wrong_config():
    with pytest.raises(ValueError):
        tw = TestWrangler(config={'baseseses_path': 'trdpipe/structify/test/data'}, params={})
        assert issubclass(tw, BaseWrangler)
        p = tw._BaseWrangler__getPath(stage="raw")


def test_findFileWithMaxDate():
    bw = BaseWrangler(config={}, params=None)
    fls = ['/hollywood/actors/actors_movies.csv',
           '/hollywood/actors/actors_movies_20210903.csv',
           '/hollywood/actors/actors_movies_20210901.csv']
    f = bw._BaseWrangler__findFileWithMaxDate(fls)
    assert f == '/hollywood/actors/actors_movies_20210903.csv'


def test_findFilesMaxDate():
    bw = BaseWrangler(config={}, params=None)
    fls = ['/hollywood/actors/actors_movies.csv',
           '/hollywood/actors/actors_movies_20210903.csv',
           '/hollywood/actors/actors_movies_20210901.csv']
    f = bw._BaseWrangler__findFilesMaxDate(fls)
    assert f == '20210903'


def test_findFileWithMaxDate_error():
    with pytest.raises(ValueError):
        bw = BaseWrangler(config={}, params=None)
        fls = ['/hollywood/actors/actors_movies.csv']
        f = bw._BaseWrangler__findFileWithMaxDate(fls)


def test_findLatestDate():
    tw = TestWrangler(config={'base_path': 'trdpipe/structify/test/data'}, params={})
    assert issubclass(tw, BaseWrangler)
    latestDate = tw._findLatestDate(
        "actors_movies", "csv", BaseWrangler.STAGE_RAW)
    assert latestDate == '20210903'


def test_findLatestDate_nofiles():
    tw = TestWrangler(config={'base_path': 'trdpipe/structify/test/data'}, params={})
    assert issubclass(tw, BaseWrangler)
    latestDate = tw._findLatestDate(
        "actors_villas", "csv", BaseWrangler.STAGE_RAW)
    assert latestDate is None


def test_getLatest():
    tw = TestWrangler(config={'base_path': 'trdpipe/structify/test/data'}, params={})
    assert issubclass(tw, BaseWrangler)
    latest = tw._findLatest("actors_movies", "csv", BaseWrangler.STAGE_RAW)
    assert os.path.split(latest)[1] == 'actors_movies_20210903.csv'


def test_getLatest_nofiles():
    tw = TestWrangler(config={'base_path': 'trdpipe/structify/test/data'}, params={})
    assert issubclass(tw, BaseWrangler)
    latest = tw._findLatest("actors_villas", "csv", BaseWrangler.STAGE_RAW)
    assert latest is None


def test_getLatest_wrongpath():
    with pytest.raises(ValueError):
        tw = TestWrangler(config={'base_path': 'testing/data'}, params={})
        assert issubclass(tw, BaseWrangler)
        tw._findLatest("actors_movies", "csv", BaseWrangler.STAGE_RAW)


def test_getLatest_unknownstage():
    with pytest.raises(ValueError):
        tw = TestWrangler(config={'base_path': 'trdpipe/structify/test/data'}, params={})
        assert issubclass(tw, BaseWrangler)
        tw._findLatest("actors_movies", "csv", "kindergarten")


def test_extractBucket():
    bw = BaseWrangler(config={}, params=None)
    bucket = bw._BasePipe__extractBucket("gs://mybucket/sub1/sub2/../uuh")
    assert bucket == "mybucket"


def test_extractBucketPath():
    bw = BaseWrangler(config={}, params=None)
    bp = bw._BasePipe__extractBucketPath("gs://mybucket/sub1/sub2/../uuh")
    assert bp == "sub1/sub2/../uuh"


def test_findLatest_gcp():
    tw = TestWrangler(
        config={'base_path': 'gs://trd-dwh-dev/datalake'}, params={})
    assert issubclass(tw, BaseWrangler)
    latest = tw._findLatest("actors_movies", "csv", BaseWrangler.STAGE_RAW)
    assert os.path.split(
        latest)[1] == 'datalake0_rawhollywoodactorsactors_movies_20210903.csv'

def test_findLatest_gcp_workdir():
    tw = TestWrangler(
        config={
            'base_path': 'gs://trd-dwh-dev/datalake',
            'workdir':'trdpipe/structify/test/tmp'}, 
        params={})
    assert issubclass(tw, BaseWrangler)
    latest = tw._findLatest("actors_movies", "csv", BaseWrangler.STAGE_RAW)
    assert os.path.split(
        latest)[1] == 'datalake0_rawhollywoodactorsactors_movies_20210903.csv'

def test_push():
    tw = actors.Wrangler(config={'base_path': 'trdpipe/structify/test/data'}, params={})
    assert issubclass(tw, BaseWrangler)
    df = pd.DataFrame({'col1': [1, 2], 'col2': [3, 4]})
    tw._push(dataset="movies_clean", data=df, timestamp="20220101",
             formats=BaseWrangler.FORMAT_CSV)


def test_push_timestamp_exists():
    tw = actors.Wrangler(config={'base_path': 'trdpipe/structify/test/data'}, params={})
    assert issubclass(tw, BaseWrangler)
    df = pd.DataFrame(
        {'col1': [1, 2], 'col2': [3, 4], 'timestamp': [None, None]})
    tw._push(dataset="movies_clean", data=df, timestamp="20220101",
             formats=BaseWrangler.FORMAT_CSV, add_timestamp2data=False)


def test_push_timestamp_exists2():
    tw = actors.Wrangler(config={'base_path': 'trdpipe/structify/test/data'}, params={})
    assert issubclass(tw, BaseWrangler)
    df = pd.DataFrame(
        {'col1': [1, 2], 'col2': [3, 4], 'timestamp': [None, None]})
    with pytest.raises(ValueError):
        tw._push(dataset="movies_clean", data=df, timestamp="20220101",
                 formats=BaseWrangler.FORMAT_CSV)


def test_push_multiple_formats():
    tw = actors.Wrangler(config={'base_path': 'trdpipe/structify/test/data'}, params={})
    assert issubclass(tw, BaseWrangler)
    df = pd.DataFrame({'col1': [1, 2], 'col2': [3, 4]})
    tw._push(dataset="movies_clean", data=df, timestamp="20220101",
             formats=BaseWrangler.FORMAT_CSV+","+BaseWrangler.FORMAT_PARQUET)


def test_push_nodata():
    with pytest.raises(ValueError):
        tw = TestWrangler(config={'base_path': 'trdpipe/structify/test/data'}, params={})
        assert issubclass(tw, BaseWrangler)
        tw._push(dataset="movies_clean", data=None, timestamp="20220101",
                 formats=BaseWrangler.FORMAT_CSV)


def test_push_nodataset():
    with pytest.raises(ValueError):
        tw = TestWrangler(config={'base_path': 'trdpipe/structify/test/data'}, params={})
        assert issubclass(tw, BaseWrangler)
        tw._push(dataset="", data=pd.DataFrame({'col1': [1, 2], 'col2': [3, 4]}), timestamp="20220101",
                 formats=BaseWrangler.FORMAT_CSV)


def test_push_invaliddataset():
    with pytest.raises(ValueError):
        tw = TestWrangler(config={'base_path': 'trdpipe/structify/test/data'}, params={})
        assert issubclass(tw, BaseWrangler)
        tw._push(dataset="movies.clean", data=pd.DataFrame({'col1': [1, 2], 'col2': [3, 4]}), timestamp="20220101",
                 formats=BaseWrangler.FORMAT_CSV)


def test_push_wrongtimestamp():
    with pytest.raises(ValueError):
        tw = TestWrangler(config={'base_path': 'trdpipe/structify/test/data'}, params={})
        assert issubclass(tw, BaseWrangler)
        tw._push(dataset="movies_clean", data=pd.DataFrame({'col1': [1, 2], 'col2': [3, 4]}), timestamp="76718",
                 formats=BaseWrangler.FORMAT_CSV)


def test_push_dataformat_unknown():
    with pytest.raises(ValueError):
        tw = TestWrangler(config={'base_path': 'trdpipe/structify/test/data'}, params={})
        assert issubclass(tw, BaseWrangler)
        tw._push(dataset="movies_clean", data=pd.DataFrame({'col1': [1, 2], 'col2': [3, 4]}), timestamp="20220101",
                 formats="spss")


def test_push_gcp():
    tw = actors.Wrangler(
        config={'base_path': 'gs://trd-dwh-dev/datalake'}, params={})
    assert issubclass(tw, BaseWrangler)
    df = pd.DataFrame({'col1': [1, 2], 'col2': [3, 4]})
    tw._push(dataset="movies_clean", data=df, timestamp="20220101",
             formats=BaseWrangler.FORMAT_CSV)


def test_collectSubSources():
    tw = TestWranglerStudies(config={'base_path': 'trdpipe/structify/test/data'}, params={})
    subsrcs = tw._collectSubSources(BaseWrangler.STAGE_RAW)
    assert subsrcs is not None
    assert len(subsrcs) == 2
    assert 'i_1' in subsrcs
    assert 'i_2' in subsrcs

def test_collectSubSources_GCP():
    tw = TestWranglerStudies(config={'base_path': 'gs://trd-dwh-dev/datalake'}, params={})
    subsrcs = tw._collectSubSources(BaseWrangler.STAGE_RAW)
    assert subsrcs is not None
    assert len(subsrcs) == 2
    assert 'i_1' in subsrcs
    assert 'i_2' in subsrcs