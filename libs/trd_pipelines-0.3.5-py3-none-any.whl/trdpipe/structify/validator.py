import pathlib
import json
import os
import jsonschema

class Validator():

    def __init__(self):
        pass

    def validate(self, df, schema):
        json_data = df.to_json(orient="records")
        json_data = json.loads(json_data)
        table_schema = {
            "type" : "array",
            "items" : schema
        }
        jsonschema.validate(json_data, table_schema)

    def getJsonSchema(self, root, dataset):
        basePath = pathlib.Path(root).parent
        fileName = basePath.joinpath(
            "meta").joinpath(
                f"meta_{dataset}.json")

        try:
            with open(fileName) as sf:
                schema = json.load(sf)

            # check if it is as valid json schema definition
            jsonschema.Draft202012Validator.check_schema(schema)

            return schema
        except FileNotFoundError:
            msg = f"no meta data (as json schema) provided for dataset {dataset}"
            msg = msg + \
                f"\nyou should place it in {os.path.split(fileName)[0]}"
            msg = msg + f" and name it {os.path.split(fileName)[1]}"
            raise ValueError(msg)
        except jsonschema.SchemaError:
            raise ValueError(
                f"the provided json schema is not a valid json schema")